# Credit-Score
data from the kaggle 'give me some credit" competition

credit scoring by predicting the probability that somebody will experience financial distress in the next two years
