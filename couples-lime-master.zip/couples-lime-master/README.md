# couples-lime

[Notebook](https://github.com/fastforwardlabs/couples-lime/blob/master/couples-lime.ipynb)
demonstrating the use of LIME to interpret a random forest model of predicting
whether a relationship is going to last, or not. This notebook is accompanied
by a [post on the Fast Forward Lab's
blog](http://blog.fastforwardlabs.com/2017/09/01/LIME-for-couples.html). 
